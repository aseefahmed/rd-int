myApp = angular.module('myApp', []);

angular.module('myApp', []).config(function($interpolateProvider){
    $interpolateProvider.startSymbol('<%').endSymbol('%>');
});

var app = {};

app.host = 'http://127.0.0.1:8000/';




