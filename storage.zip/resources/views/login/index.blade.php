<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class=" js "><!--<![endif]--><head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>MyZone - User Login</title>
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
	 
	<link rel="stylesheet" href="{{ asset('public/css/all.css') }}">
</head>
<body class="bg-login printable" ng-app="myApp" ng-controller="LoginController">
	<div class="login-screen">
		<div class="panel-login blur-content">
			<div class="panel-heading">
				<img src="login_files/teamfox.png" alt="" height="100">
			</div> 
			<div id="pane-login" class="panel-body active">
				<h2>Login to Dashboard</h2>
				<form name="loginForm">
					{{ csrf_field() }}
					<div class="form-group">
						<div class="inputer">
							<div class="input-wrapper">
								<input class="form-control" placeholder="Enter your email address" type="text" ng-model="email">
							</div>
						</div>
					</div> 
					<div class="form-group">
						<div class="inputer">
							<div class="input-wrapper">
								<input class="form-control" placeholder="Enter your password" type="password" ng-model="password">
							</div>
						</div>
					</div> 
					<div class="form-buttons clearfix">
						<label class="pull-left">
							<input name="rememberme" id="rememberme" type="checkbox"> Remember me
						</label>
						<button type="submit" ng-click="doLogin()" class="btn btn-success pull-right btn-ripple">Login</button>
					</div> 
				</form>
				<div class="social-accounts">
					<div class="btn-group btn-merged btn-group-justified">
						<div class="btn-group">
							<a class="btn btn-social btn-facebook btn-ripple"><i class="fa fa-facebook"></i> Facebook</a>
						</div>
						<div class="btn-group">
							<a class="btn btn-social btn-github btn-ripple"><i class="fa fa-github"></i> Github</a>
						</div>
					</div>
				</div> 
				<ul class="extra-links">
					<li><a href="#" class="show-pane-forgot-password">Forgot your password</a></li>
					<li><a href="#" class="show-pane-create-account">Create a new account</a></li>
					<li ng-if="login_failed_alert"><a href="#" class="alert alert-danger"><% login_failed_alert %></a></li>

				</ul>
			</div> 
			<div id="pane-forgot-password" class="panel-body">
				<h2>Forgot Your Password</h2>
				<div class="form-group">
					<div class="inputer">
						<div class="input-wrapper">
							<input class="form-control" placeholder="Enter your email address" type="email">
						</div>
					</div>
				</div> 
				<div class="form-buttons clearfix">
					<button type="submit" class="btn btn-white pull-left show-pane-login btn-ripple">Cancel</button>
					<button type="submit" class="btn btn-success pull-right btn-ripple">Send</button>
				</div> 
			</div> 
			<div id="pane-create-account" class="panel-body">
				<h2>Create a New Account</h2>
					<div class="form-group">
						<div class="inputer">
							<div class="input-wrapper">
								<input class="form-control" placeholder="Enter your full name" type="text">
							</div>
						</div>
					</div> 
					<div class="form-group">
						<div class="inputer">
							<div class="input-wrapper">
								<input class="form-control" placeholder="Enter your email address" type="email">
							</div>
						</div>
					</div> 
					<div class="form-group">
						<div class="inputer">
							<div class="input-wrapper">
								<input class="form-control" placeholder="Enter your password" type="password">
							</div>
						</div>
					</div> 
					<div class="form-group">
						<div class="inputer">
							<div class="input-wrapper">
								<input class="form-control" placeholder="Enter your password again" type="password">
							</div>
						</div>
					</div> 
					<div class="form-group">
						<label>
							<input name="remember" value="1" type="checkbox"> I have read and agree to the term of use.
						</label>
					</div>
					<div class="form-buttons clearfix">
						<button type="submit" class="btn btn-whit e pull-left show-pane-login btn-ripple">Cancel</button>
						<button type="submit" class="btn btn-success pull-right btn-ripple">Sign Up</button>
					</div> 
				</div> 
			</div> 
		</div> 
	<div class="bg-blur dark active">
		<div class="overlay"></div> 
	</div> 
	<svg version="1.1" xmlns="http://www.w3.org/2000/svg">
		<filter id="blur">
			<feGaussianBlur stdDeviation="7"></feGaussianBlur>
		</filter>
	</svg>
	 
	<script src="{{ asset('public/js/all.js') }}"></script>
	<script src="{{ asset('public/js/lib/angular_js/angular.min.js') }}"></script>
	<script src="{{ asset('public/js/main.js') }}"></script>
	<script src="{{ asset('public/js/controllers/login.js') }}"></script>
	<script>
		$(document).ready(function () {
			$.ajaxSetup({
	            headers: {
	                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
	            }
	        });
			Pleasure.init();
			Layout.init();
			UserPages.login();
		});
	</script>
</body>
</html>