<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middlewere' => 'web'], function(){
    Route::get('/login', ['uses' => 'LoginController@index', 'as' => 'login']);
    Route::post ('/process-login', ['uses' => 'LoginController@processLogin', 'as' => 'Process Login']);

    Route::get('/buying/orders', ['uses' => 'BuyingOrderController@index', 'as' => 'buying_ordrer']);
    Route::get('/buying/colors', ['uses' => 'ColorsController@index', 'as' => 'colors']);
    Route::get('/buying/color/{id}', ['uses' => 'ColorsController@getColorDetails', 'as' => 'colors']);
    Route::get('/buying/colorsList', ['uses' => 'ColorsController@getColorsList', 'as' => 'colors_list']);
    Route::get('/buying/order/{id}', ['uses' => 'BuyingOrderController@getOrderDetails', 'as' => 'buying_ordrer']);
    Route::get('/buying/order/pricechart/{id}', ['uses' => 'BuyingOrderController@loadPriceChart', 'as' => 'price_chart']);
    Route::get('/buying/ordersList', ['uses' => 'BuyingOrderController@ordersList', 'as' => 'buying_ordrers_list']);
    Route::get('/buying/order/price/confirm/{order_id}/{supplier_id}/{price}', ['uses' => 'BuyingOrderController@confirmPrice', 'as' => 'buying_ordrers_list']);
    Route::get('buying/getOrdersSummery', ['uses' => 'BuyingOrderController@getOrdersSummery', 'as' => 'orders_summery']);
    Route::get('buying/getSummery/{id}', ['uses' => 'BuyingOrderController@getSummery', 'as' => 'summery']);
    Route::post('buying/orders/store', ['uses' => 'BuyingOrderController@storeOrders', 'as' => 'Orders']);
    Route::post('buying/color/store', ['uses' => 'ColorsController@storeColor', 'as' => 'store_color']);
    Route::post('buying/order/pricechart/save', ['uses' => 'BuyingOrderController@savePriceChart', 'as' => 'price_chart']);
    Route::post('buying/buyers/store', ['uses' => 'BuyersController@storeBuyer', 'as' => 'Buyer']);
    Route::post('buying/suppliers/store', ['uses' => 'SuppliersController@storeSupplier', 'as' => 'Supplier']);
    Route::post('buying/order/update', ['uses' => 'BuyingOrderController@updateOrder', 'as' => 'Orders']);
    Route::post('buying/color/update', ['uses' => 'ColorsController@updateColor', 'as' => 'Color']);
    Route::post('buying/buyer/update', ['uses' => 'BuyersController@updateBuyer', 'as' => 'Buyers']);
    Route::post('buying/supplier/update', ['uses' => 'SuppliersController@updateSupplier', 'as' => 'Suppliers']);
    Route::post('buying/order/uploadFiles', ['uses' => 'BuyingOrderController@uploadFiles', 'as' => 'Orders Documents']);
    Route::get('/buying/buyers', ['uses' => 'BuyersController@viewBuyersList', 'as' => 'Buyers']);
    Route::get('/buying/suppliers', ['uses' => 'SuppliersController@viewSuppliersList', 'as' => 'Suppliers']);
    Route::get('/buying/getbuyersList', ['uses' => 'BuyersController@getbuyersList', 'as' => 'Buyers']);
    Route::get('/buying/buyer/{id}', ['uses' => 'BuyersController@getBuyerDetails', 'as' => 'Buyer Details']);
    Route::get('/buying/supplier/{id}', ['uses' => 'SuppliersController@getSupplierDetails', 'as' => 'Supplier Details']);


    Route::get('hrm/employees', ['uses' => 'EmployeesController@viewEmployeesList', 'as' => 'employees']);
    Route::get('hrm/employeesList', ['uses' => 'EmployeesController@getemployeesList', 'as' => 'employees']);
    Route::post('hrm/employee/add', ['uses' => 'EmployeesController@storeEmployee', 'as' => 'add_employee']);
    Route::get('hrm/employee/{id}', ['uses' => 'EmployeesController@viewEmployeeDetails', 'as' => 'view_employee']);
    Route::post('hrm/employee/update', ['uses' => 'EmployeesController@updateEmployeeDetails', 'as' => 'update_employee']);


    Route::get('dashboard/calendar/{id}', ['uses' => 'CalendarController@viewCalendar', 'as' => 'calendar']);
    Route::get('dashboard/loadEvents/{id}', ['uses' => 'CalendarController@loadEvents', 'as' => 'loadEvents']);
    Route::post('dashboard/event/add', ['uses' => 'CalendarController@addEvent', 'as' => 'addEvents']);
    Route::get('dashboard/event/{id}/{ref}', ['uses' => 'CalendarController@viewEventDetails', 'as' => 'Event']);
    Route::get('dashboard/eventFlag/{evt_ref}/{user_id}/{flag}', ['uses' => 'CalendarController@changeEventFlag', 'as' => 'Event']);


});
