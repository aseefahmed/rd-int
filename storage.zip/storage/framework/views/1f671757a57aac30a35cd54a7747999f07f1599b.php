<?php $__env->startSection('content'); ?>
    <?php
        $days_left = date_diff(date_create($order[0]->handover_date), date_create($today))->d;
    ?>
    <form class="col s12" id="edit_order_form" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

    <div id="attach_files" class="modal modal-fixed-footer">
            <div class="modal-content">
                <input type="hidden" name="reference_id" id="reference_id" value="<?php echo e($order[0]->id); ?>">
                <div class="row">
                    <div class="input-field col s6">
                        <select name="doc_type">
                            <option value="PO">PO</option>
                            <option value="Report">Report</option>
                            <option value="Picture">Picture</option>
                        </select>
                        <label>Document Type</label>
                    </div>

                    <div class="input-field col s6">
                        <input name="description" type="text">
                        <label>Description</label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s12">
                        <input id="input_file" name="file" type="file" class="file-loading"><br><br><br><br><br><br>
                        <label class="control-label">Select File</label>
                    </div>
                </div>
            </div>
            <div class="modal-footer green lighten-4">
                <a href="#" class="waves-effect waves-red btn modal-action modal-close">Disagree</a>
                <a href="#" class="waves-effect waves-light light-blue btn modal-action modal-close" id="file_upload">Agree</a>
            </div>
        </div>
    <div class="row" ng-controller="BuyingOrderController"  ng-init="ordersSummery()">
        <div class="col-sm-12">
            <div class="col-sm-6 text-left">
                <h4 class="header">
                    Order Details
                    <?php if($days_left <= 30): ?>
                        <div class="chip red darken-1 white-text">
                           <i class="mdi-action-report-problem"></i> urgent
                        </div>
                    <?php endif; ?>
                </h4></div>
            <div class="col-sm-6 text-right">
                <div class="fixed-action-btn horizontal">
                    <a class="btn-floating btn-large red">
                        <i class="mdi-social-notifications-none"></i>
                    </a>
                    <ul>
                        <li><a class="btn-floating green modal-trigger" href="#attach_files"><i class="large mdi-editor-publish"></i></a></li>
                    </ul>
                </div>
            </div>
            <ol class="breadcrumbs">
                <li><a href="index.html">Dashboard</a></li>
                <li><a href="#">Tables</a></li>
                <li class="active">Basic Tables</li>
            </ol>
            <div class="row">
                <div class="col s12 m6 l3">
                    <div class="card">
                        <div class="card-content  green white-text">
                            <p class="card-stats-title"><i class="mdi-social-group-add"></i> Progress</p>
                            <h4 class="card-stats-number"><?php echo e($order[0]->progress); ?>%</h4>
                            <p class="card-stats-compare">Completed</span>
                            </p>
                        </div>
                        <div class="card-action  green darken-2">
                            <div id="clients-bar" class="center-align"></div>
                        </div>
                    </div>
                </div>
                <div class="col s12 m6 l3">
                    <div class="card">
                        <div class="card-content purple white-text">
                            <p class="card-stats-title"><i class="mdi-editor-attach-money"></i>Total Documents</p>
                            <h4 class="card-stats-number"><?php echo e($total_documents); ?></h4>
                            <p class="card-stats-compare">Uploaded</span>
                            </p>
                        </div>
                        <div class="card-action purple darken-2">
                            <div id="sales-compositebar" class="center-align"></div>

                        </div>
                    </div>
                </div>
                <div class="col s12 m6 l3">
                    <div class="card">
                        <div class="card-content blue-grey white-text">
                            <p class="card-stats-title"><i class="mdi-action-trending-up"></i> Shipping Date</p>
                            <h4 class="card-stats-number"><?php echo e($days_left); ?></h4>
                            <p class="card-stats-compare">Days left</span>
                            </p>
                        </div>
                        <div class="card-action blue-grey darken-2">
                            <div id="profit-tristate" class="center-align"></div>
                        </div>
                    </div>
                </div>
                <div class="col s12 m6 l3">
                    <div class="card">
                        <div class="card-content deep-purple white-text">
                            <p class="card-stats-title"><i class="mdi-editor-insert-drive-file"></i> Last Updated</p>
                            <h4 class="card-stats-number"><?php echo e(date_format(date_create($order[0]->updated_at),'dS M')); ?></h4>
                            <h4 class="card-stats-number"><?php echo e(date_format(date_create($order[0]->updated_at),'Y')); ?></h4>
                            </p>
                        </div>
                        <div class="card-action  deep-purple darken-2">
                            <div id="invoice-line" class="center-align"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            <div class="divider"></div>
            <div class="row">
                <div class="col s8">

                    <p><a class="waves-effect waves-light  btn" href="<?php echo e(url('buying/order/pricechart/'.$order[0]->id)); ?>">Price Chart</a></p>
                    <div class="card-panel">
                        <div class="row">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($order[0]->id); ?>">
                            <div class="row">
                                <div class="input-field col s3">
                                    <select name="supplier_id">
                                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value="<?php echo e($supplier->id); ?>" <?php if($supplier->id == $order[0]->supplier_id){echo "selected";} ?>><?php echo e($supplier->supplier_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                                    <label>Factory</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="session" type="text" value="<?php echo e($order[0]->session); ?>">
                                    <label>Season</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="style" type="text" value="<?php echo e($order[0]->style); ?>">
                                    <label>Style</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="ref" type="text" value="<?php echo e($order[0]->ref); ?>">
                                    <label>Ref</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s3">
                                    <select name="customer">
                                        <?php $__currentLoopData = $buyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value="<?php echo e($buyer->id); ?>" <?php if($buyer->id == $order[0]->customer){echo "selected";} ?>><?php echo e($buyer->buyer_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                                    <label>Customer</label>
                                </div>
                                <div class="input-field col s3">
                                    <input name="shipping_sample_required" type="text" value="<?php echo e($order[0]->shipping_sample_required); ?>">
                                    <label>Shipping Sample Requirements</label>
                                </div>
                                <div class="input-field col s3">
                                    <input name="shipping_sample_sent" type="text" value="<?php echo e($order[0]->shipping_sample_sent); ?>">
                                    <label>Shipping Sample Sent</label>
                                </div>
                                <div class="input-field col s3">
                                    <input name="shipping_sent_courier_no" type="text" value="<?php echo e($order[0]->shipping_sent_courier_no); ?>">
                                    <label>Courier No</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s3">
                                    <input name="accessories" type="text" value="<?php echo e($order[0]->accessories); ?>">
                                    <label>Accessories</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="overseas_accessories" type="text" value="<?php echo e($order[0]->overseas_accessories); ?>">
                                    <label>Overseas Accessories	</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="accys_status" type="text" value="<?php echo e($order[0]->accys_status); ?>">
                                    <label>Overseas Accessories Status</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="care_label_composition" type="text" value="<?php echo e($order[0]->care_label_composition); ?>">
                                    <label>	Care Label Composition</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s3">
                                    <input name="ca_rn" type="text" value="<?php echo e($order[0]->ca_rn); ?>">
                                    <label>CA/RN</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="fit_sample_sent" type="text" value="<?php echo e($order[0]->fit_sample_sent); ?>">
                                    <label>Fit Sample Sent	</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="courier_no" type="text" value="<?php echo e($order[0]->courier_no); ?>">
                                    <label>Courier No.</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="fit_sample_comments" type="text" value="<?php echo e($order[0]->fit_sample_comments); ?>">
                                    <label>Fit Sample Comments</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s3">
                                    <input name="yarn" type="text" value="<?php echo e($order[0]->yarn); ?>">
                                    <label>Yarn</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="ply" type="text" value="<?php echo e($order[0]->ply); ?>">
                                    <label>Ply</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="knitting_pattern" type="text" value="<?php echo e($order[0]->knitting_pattern); ?>">
                                    <label>Knitting Pattern</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="trims" type="text" value="<?php echo e($order[0]->trims); ?>">
                                    <label>Trims</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s3">
                                    <input name="Gauge" type="text" value="<?php echo e($order[0]->Gauge); ?>">
                                    <label>Gauge</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="yarn_ref_details" type="text" value="<?php echo e($order[0]->yarn_ref_details); ?>">
                                    <label>Yarn (Ref.)</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="contract_weight" type="text" value="<?php echo e($order[0]->contract_weight); ?>">
                                    <label>Contract Weight</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="sizing" type="text" value="<?php echo e($order[0]->sizing); ?>">
                                    <label>Sizing</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s4">
                                    <input type="date" name="po_recieved_date" value="<?php echo e($order[0]->po_recieved_date); ?>" class="datepicker">
                                    <label for="dob">PO Date</label>
                                </div>
                                <div class="input-field col s4">
                                    <input type="date" name="pi_date" value="<?php echo e($order[0]->pi_date); ?>" class="datepicker">
                                    <label for="dob">PI Date</label>
                                </div>
                                <div class="input-field col s4">
                                    <input type="date" name="handover_date" value="<?php echo e($order[0]->handover_date); ?>" class="datepicker">
                                    <label for="dob">Shipment Date</label>
                                </div>
                            </div>

                            <div class="row">

                                <div class="input-field col s12">
                                    <input name="remarks" type="text" value="<?php echo e($order[0]->remarks); ?>">
                                    <label>Remarks</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12">
                                    <a class="waves-effect waves-light  btn"><i class="mdi-navigation-apps left"></i>Production</a>
                                </div>
                                <div class="input-field col s12">
                                    <div></div>
                                    <div id="range_02" progress="<?php echo e($order[0]->progress); ?>"></div>
                                </div>
                                <div class="input-field col s2">
                                    <?php if($order[0]->knitting == "Completed"): ?>
                                        <input name="knitting" class="production_progress" type="checkbox" id="test4" value="Completed" checked />
                                    <?php else: ?>
                                        <input name="knitting" class="production_progress" type="checkbox" id="test4" value="Completed"  />
                                    <?php endif; ?>
                                    <label for="test4">Knitting</label>
                                </div>
                                <div class="input-field col s2">
                                    <?php if($order[0]->linking == "Completed"): ?>
                                        <input name="linking" class="production_progress" type="checkbox" id="test5" value="Completed" checked />
                                    <?php else: ?>
                                        <input name="linking" class="production_progress" type="checkbox" id="test5" value="Completed"  />
                                    <?php endif; ?>
                                    <label for="test5">Linking</label>
                                </div>
                                <div class="input-field col s2">
                                    <?php if($order[0]->finishing == "Completed"): ?>
                                        <input name="finishing" class="production_progress" type="checkbox" id="test6" value="Completed" checked />
                                    <?php else: ?>
                                        <input name="finishing" class="production_progress" type="checkbox" id="test6" value="Completed"  />
                                    <?php endif; ?>
                                    <label for="test6">Finishing</label>
                                </div>

                                <div class="input-field col s2">
                                    <?php if($order[0]->packing == "Completed"): ?>
                                        <input name="packing" class="production_progress" type="checkbox" id="test7" value="Completed" checked />
                                    <?php else: ?>
                                        <input name="packing" class="production_progress" type="checkbox" id="test7" value="Completed"  />
                                    <?php endif; ?>
                                    <label for="test7">Packing</label>
                                </div>
                            </div>

                            <div class="row">
                                <div class="input-field col s12">
                                    <a class="waves-effect waves-light  btn"><i class="mdi-editor-attach-money left"></i>Color</a>
                                </div>
                                <?php $__currentLoopData = $yarn_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <div class="input-field col s2">
                                        <input name="color_<?php echo e($yarn->id); ?>" class="production_progress" type="checkbox" id="color_<?php echo e($yarn->id); ?>" value="1" />
                                        <label><?php echo e($yarn->yarn_type); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                            </div>

                            <div class="row">
                                <div class="input-field col s12">
                                    <a class="waves-effect waves-light  btn"><i class="mdi-editor-attach-money left"></i>Final Weight / Price</a>
                                </div>
                                <div class="input-field col s2">
                                    <input name="approved_weight" type="text" value="<?php echo e($order[0]->approved_weight); ?>">
                                    <label>Approved Weight</label>
                                </div>
                                <div class="input-field col s2">
                                    <input name="actual_production_weight" type="text" value="<?php echo e($order[0]->actual_production_weight); ?>">
                                    <label>Actual Weight</label>
                                </div>
                                <div class="input-field col s2">
                                    <input name="qty" type="text" value="<?php echo e($order[0]->qty); ?>">
                                    <label>Qty</label>
                                </div>

                                <div class="input-field col s2">
                                    <input name="price" type="text" value="<?php echo e($order[0]->price); ?>">
                                    <label>Price</label>
                                </div>

                                <div class="input-field col s2">
                                    <input name="confirmed_price" type="text" value="<?php echo e($order[0]->confirmed_price); ?>">
                                    <label>Confirmed Price</label>
                                </div>

                                <div class="input-field col s2">
                                    <input name="value" type="text" value="<?php echo e($order[0]->confirmed_price * $order[0]->qty); ?>" readonly>
                                    <label>Order Value</label>
                                </div>
                            </div>

                            <div class="row">
                                <div class="input-field col s12">
                                    <a class="waves-effect waves-light  btn"><i class="mdi-maps-local-shipping left"></i>Delivery Info</a>
                                </div>
                                <div class="input-field col s3">
                                    <input name="inspection_date" class="datepicker" type="text" value="<?php echo e($order[0]->inspection_date); ?>">
                                    <label>Inspection Date</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="handedover_date" class="datepicker" type="text" value="<?php echo e($order[0]->handedover_date); ?>">
                                    <label>HandedOver Date</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="handedover_qty" type="text" value="<?php echo e($order[0]->handedover_qty); ?>">
                                    <label>Handedover Qty</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12">
                                    <a class="waves-effect waves-light  btn"><i class="mdi-action-account-balance left"></i>Shipping Info</a>
                                </div>
                                <div class="input-field col s3">
                                    <input name="mode" type="text" value="<?php echo e($order[0]->mode); ?>">
                                    <label>Mode</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="destination" type="text" value="<?php echo e($order[0]->destination); ?>">
                                    <label>Destination</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="shipping_hbl_awb" type="text" value="<?php echo e($order[0]->shipping_hbl_awb); ?>">
                                    <label>hbl_awb</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="shipping_vsl_flight" type="text" value="<?php echo e($order[0]->shipping_vsl_flight); ?>" >
                                    <label>M.Vsl / Flight</label>
                                </div>


                                <div class="input-field col s3">
                                    <input name="shipping_etd" class="datepicker" type="text" value="<?php echo e($order[0]->shipping_etd); ?>">
                                    <label>ETD</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="shipping_eta" class="datepicker" type="text" value="<?php echo e($order[0]->shipping_eta); ?>">
                                    <label>ETA</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="shipping_master_lc" type="text" value="<?php echo e($order[0]->shipping_master_lc); ?>">
                                    <label>Master L/C</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="shipping_invoice" type="text" value="<?php echo e($order[0]->shipping_invoice); ?>">
                                    <label>Invoice</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="shipping_invoice_value" type="text" value="<?php echo e($order[0]->shipping_invoice_value); ?>" >
                                    <label>Invoice value</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12">
                                    <a class="waves-effect waves-light  btn"><i class="mdi-communication-email left"></i>Document Info</a>
                                </div>
                                <div class="input-field col s3">
                                    <input name="doc_status" type="text" value="<?php echo e($order[0]->doc_status); ?>">
                                    <label>Document status</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="doc_sent_courier_no" type="text" value="<?php echo e($order[0]->doc_sent_courier_no); ?>">
                                    <label>Tracking #</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="doc_date" type="text" value="<?php echo e($order[0]->doc_date); ?>">
                                    <label>Date</label>
                                </div>

                                <div class="input-field col s3">
                                    <input name="payment" type="text" value="<?php echo e($order[0]->payment); ?>">
                                    <label>Payment</label>
                                </div>
                                <div class="input-field col s3">
                                    <input name="payment_date" type="text" value="<?php echo e($order[0]->payment_date); ?>">
                                    <label>Payment Date</label>
                                </div>
                            </div>

                            <div class="row">
                                <div class="input-field col s12">
                                    <button class="btn cyan waves-effect waves-light right" type="submit" id="edit_order" name="action">Edit
                                        <i class="mdi-content-send right"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php echo $__env->make('partials.order_details_partial', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('partials.merchandiser_widget', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('partials.activities', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

        </div>

    </div>


    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>