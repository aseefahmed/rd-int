<?php
    $order_summery = getOrderSummery();
?>
<div class="col s4">
    <ul class="collapsible collapsible-accordion" data-collapsible="accordion">
        <li>
            <div class="collapsible-header purple white-text active"><i class="mdi-device-access-alarms"></i> Orders Shipping Soon</div>
            <div class="collapsible-body purple lighten-5">
                <div class="collection">
                    <?php $__currentLoopData = $order_summery['orders_shipping_soon']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <a href="<?php echo e(url('buying/order/'.$order->id )); ?>" class="collection-item"><?php echo e($order->style); ?><span class="new badge"><?php echo e($order->progress); ?>% completed</span></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php if(count($order_summery['orders_shipping_soon']) == 0): ?>
                        <a class="collection-item">No orders found</a>
                    <?php endif; ?>
                </div>
            </div>
        </li>
        <li>
            <div class="collapsible-header red white-text"><i class="mdi-device-battery-charging-20"></i> Recent Orders</div>
            <div class="collapsible-body red lighten-5 lighten-5">
                <div class="collection">
                    <?php $__currentLoopData = $order_summery['recent_orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <a href="<?php echo e(url('buying/order/'.$order->id )); ?>" class="collection-item"><?php echo e($order->style); ?><span class="new badge"><?php echo e($order->progress); ?>% completed</span></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php if(count($order_summery['recent_orders']) == 0): ?>
                        <a class="collection-item">No orders found</a>
                    <?php endif; ?>
                </div>
            </div>
        </li>
        <li>
            <div class="collapsible-header teal white-text"><i class="mdi-device-dvr"></i> Inactive Orders</div>
            <div class="collapsible-body teal lighten-5">
                <div class="collection">
                    <?php $__currentLoopData = $order_summery['inactive_orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <a href="<?php echo e(url('buying/order/'.$order->id )); ?>" class="collection-item"><?php echo e($order->style); ?><span class="new badge"><?php echo e($order->progress); ?>% completed</span></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php if(count($order_summery['inactive_orders']) == 0): ?>
                        <a class="collection-item">No orders found</a>
                    <?php endif; ?>
                </div>
            </div>
        </li>
        <li>
            <div class="collapsible-header lime darken-4 white-text"><i class="mdi-device-bluetooth-searching"></i> Recent Shipments</div>
            <div class="collapsible-body lime lighten-5">
                <div class="collection">
                    <?php $__currentLoopData = $order_summery['recent_shipments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <a href="<?php echo e(url('buying/order/'.$order->id )); ?>" class="collection-item"><?php echo e($order->style); ?><span class="new badge"><?php echo e($order->progress); ?>% completed</span></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php if(count($order_summery['recent_shipments']) == 0): ?>
                        <a class="collection-item">No orders found</a>
                    <?php endif; ?>
                </div>
            </div>
        </li>
        <li>
            <div class="collapsible-header orange white-text"><i class="mdi-device-now-widgets"></i> Suppliers</div>
            <div class="collapsible-body orange lighten-5">
                <div class="collection">
                    <?php $__currentLoopData = $order_summery['suppliers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <a href="<?php echo e(url('buying/suppliers/'.$order->supplier_id)); ?>" class="collection-item"><?php echo e($order->supplier_name); ?><span class="new badge"><?php echo e($order->total_orders); ?> orders</span></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php if(count($order_summery['suppliers']) == 0): ?>
                        <a class="collection-item">No orders found</a>
                    <?php endif; ?>
                </div>
            </div>
        </li>
    </ul>

</div>