<?php $__env->startSection('content'); ?>
    <div class="row" ng-controller="BuyingOrderController" ng-init="ordersSummery()">
        <div class="col-sm-12">
            <div class="col-sm-6 text-left"><h4 class="header">Orders</h4></div>
            <div class="col-sm-6 text-right">
                <div class="fixed-action-btn horizontal">
                    <a class="btn-floating btn-large red">
                        <i class="mdi-social-notifications-none"></i>
                    </a>
                    <ul>
                        <li><a class="btn-floating yellow darken-1"><i class="large mdi-editor-format-quote"></i></a></li>
                        <li><a class="btn-floating green"><i class="large mdi-editor-publish"></i></a>
                        </li><li><a class="btn-floating blue"><i class="large mdi-editor-attach-file"></i></a></li>
                        <li><a class="waves-effect waves-light btn modal-trigger btn-floating red" href="#add-order-modal"><i class="large mdi-content-add"></i></a></li>
                    </ul>
                </div>
            </div>
            <ol class="breadcrumbs">
                <li><a href="index.html">Dashboard</a></li>
                <li><a href="#">Tables</a></li>
                <li class="active">Basic Tables</li>
            </ol>
            <div class="divider"></div>
            <div class="row">
                <div class="col s8">
                    <div id="jsGrid-basic"></div>
                </div>
                <?php echo $__env->make('partials.orders_summery', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>

        <div id="add-order-modal" class="modal modal-fixed-footer">
            <div class="modal-content">
                <form class="col s12" name="myForm">
                    <div class="row">
                        <div class="input-field col s6">
                            <input ng-model="order.style" name="style" type="text">
                            <label>Style</label>
                        </div>

                        <div class="input-field col s6">
                            <input ng-model="order.ref" name="ref" type="text">
                            <label>Reference</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s6">
                            <input ng-model="order.gauge" name="gauge" type="text">
                            <label>Gauge</label>
                        </div>
                        <div class="input-field col s6">
                            <input ng-model="order.yarn_ref_details" name="yarn_ref_details" type="text">
                            <label>Yarn(Ref. Details)</label>
                        </div>
                    </div>
                    <div class="row">

                        <div class="input-field col s6">
                            <input ng-model="order.contract_weight" name="contract_weight"  type="text">
                            <label>Contract weight</label>
                        </div>
                        
                    </div>
                   
                </form>
            </div>
            <div class="modal-footer green lighten-4">
                <a href="#" class="waves-effect waves-red btn modal-action modal-close">Disagree</a>
                <a href="#" class="waves-effect waves-light light-blue btn modal-action modal-close" ng-click="add_buying_order(myForm)">Agree</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>