<div class="col s12 m4 l4">

    <ul id="task-card" class="collection with-header">
        <li class="collection-header cyan">
            <h4 class="task-card-title">Order Activities</h4>
            <p class="task-card-date">Since: <?php echo e(date_format(date_create($order[0]->created_at), 'dS M, Y')); ?></p>
        </li>
        <li class="collection-item dismissable">
            <input type="checkbox" id="task1" />
            <label for="task1">Create Mobile App UI. <a href="#" class="secondary-content"><span class="ultra-small">Today</span></a>
            </label>
            <span class="task-cat teal">Mobile App</span>
        </li>
        <li class="collection-item dismissable">
            <input type="checkbox" id="task2" />
            <label for="task2">Check the new API standerds. <a href="#" class="secondary-content"><span class="ultra-small">Monday</span></a>
            </label>
            <span class="task-cat purple">Web API</span>
        </li>
        <li class="collection-item dismissable">
            <input type="checkbox" id="task3" checked="checked" />
            <label for="task3">Check the new Mockup of ABC. <a href="#" class="secondary-content"><span class="ultra-small">Wednesday</span></a>
            </label>
            <span class="task-cat pink">Mockup</span>
        </li>
        <li class="collection-item dismissable">
            <input type="checkbox" id="task4" checked="checked" disabled="disabled" />
            <label for="task4">I did it !</label>
            <span class="task-cat cyan">Mobile App</span>
        </li>
    </ul>
</div>