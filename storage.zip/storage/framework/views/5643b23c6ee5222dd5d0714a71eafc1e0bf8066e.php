<?php $__env->startSection('content'); ?>
    <div class="row" ng-controller="HrmController" ng-init="ordersSummery()">
        <div class="col-sm-12">
            <div class="col-sm-6 text-left"><h4 class="header">Price Chart: <?php echo e($order[0]->style); ?></h4></div>
            <div class="col-sm-6 text-right">
                <div class="fixed-action-btn horizontal">
                    <a class="btn-floating btn-large red">
                        <i class="mdi-social-notifications-none"></i>
                    </a>
                    <ul>
                        <li><a class="btn-floating yellow darken-1"><i class="large mdi-editor-format-quote"></i></a></li>
                        <li><a class="btn-floating green"><i class="large mdi-editor-publish"></i></a>
                        </li><li><a class="btn-floating blue"><i class="large mdi-editor-attach-file"></i></a></li>
                        <li><a class="waves-effect waves-light btn modal-trigger btn-floating red" href="#add-employee-modal"><i class="large mdi-content-add"></i></a></li>
                    </ul>
                </div>
            </div>
            <ol class="breadcrumbs">
                <li><a href="index.html">Dashboard</a></li>
                <li><a href="#">Tables</a></li>
                <li class="active">Basic Tables</li>
            </ol>
            <div class="divider"></div>
            <div class="row">
                <div class="col s8">
                    <form class="col s12" name="myForm" id="myForm">
                        <?php echo e(csrf_field()); ?>

                        <?php
                            if($pricechart_count > 0){
                                $pricechart = json_decode($price_chart[0]->price_details, true);
                            }
                        ?>
                        <input type="hidden" name="orderid" id="orderid" value="<?php echo e($order[0]->id); ?>">
                        <table id="data-table-simple" class="responsive-table display" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Factory</th>
                                <th>Price($)</th>
                                <th>Weight(lbs)</th>
                                <th>Confirm</th>
                            </tr>
                        </thead>

                        <tfoot>
                            <tr>
                                <th>Factory</th>
                                <th>Price($)</th>
                                <th>Weight(lbs)</th>
                                <th>Confirm</th>
                            </tr>
                        </tfoot>

                        <tbody>
                            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <th>
                                        <?php echo e($supplier->supplier_name); ?>

                                        <input type="hidden" name="supplier_name[<?php echo e($supplier->id); ?>]" value="<?php echo e($supplier->id); ?>">
                                    </th>
                                    <th>
                                        <?php if(!isset($pricechart['price'])): ?>
                                            <input  type="number" name="price[<?php echo e($supplier->id); ?>]" id="price[<?php echo e($supplier->id); ?>]">
                                        <?php else: ?>
                                            <input  type="number"  id="price_<?php echo e($supplier->id); ?>" name="price[<?php echo e($supplier->id); ?>]" value="<?php echo e($pricechart['price'][$supplier->id ]); ?>">
                                        <?php endif; ?>
                                    </th>
                                    <th>
                                        <?php if(!isset($pricechart['weight'])): ?>
                                            <input  type="number" name="weight[<?php echo e($supplier->id); ?>]">
                                        <?php else: ?>
                                            <input  type="number" name="weight[<?php echo e($supplier->id); ?>]" value="<?php echo e($pricechart['weight'][$supplier->id ]); ?>">
                                        <?php endif; ?>
                                    </th>
                                    <th>
                                        <?php if($price_chart[0]->confirmed_supplier == $supplier->id): ?>
                                            <a supplier_id="<?php echo e($supplier->id); ?>" class="waves-effect waves-light green darken-4  btn confirm_price_btn"><i class="mdi-action-assignment-turned-in"></i></a>
                                        <?php else: ?>
                                            <a supplier_id="<?php echo e($supplier->id); ?>" class="waves-effect waves-light red darken-4  btn confirm_price_btn"><i class="mdi-action-assignment-turned-in"></i></a>
                                        <?php endif; ?>
                                    </th>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                        <p><a id="pricechart_save_btn" class="waves-effect waves-light  btn">Save</a></p>
                    </form>

                </div>
                <?php echo $__env->make('partials.orders_summery', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>