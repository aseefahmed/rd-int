<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class YarnType extends Model
{
    //
}
