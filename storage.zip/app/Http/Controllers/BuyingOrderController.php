<?php

namespace App\Http\Controllers;

use App\Buyer;
use App\BuyingOrder;
use App\Calendar;
use App\Document;
use App\Pricechart;
use App\Supplier;
use App\YarnType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class BuyingOrderController extends Controller
{
    public function index()
    {
    	return view('buying.orders');
    }

    public function ordersList()
    {
        $data['orders'] = DB::table('buying_orders')->leftJoin('suppliers', 'suppliers.id', '=', 'buying_orders.supplier_id')->leftJoin('buyers', 'buyers.id', '=', 'buying_orders.customer')->select('buying_orders.id as id', 'buying_orders.style as Style', 'buying_orders.ref as Ref','buying_orders.session as Season',
                                                                                                                                          'suppliers.supplier_name as Factory', 'buying_orders.Gauge', 'buying_orders.yarn as Yarn', 'buying_orders.ply as Ply',
            "buying_orders.knitting_pattern as KnittingPattern", 'buying_orders.trims as Trims' , 'buying_orders.contract_weight as Weight', 'buyers.buyer_name as Customer', 'buying_orders.sizing as Sizing' , 'buying_orders.overseas_accessories as OverseasAcces' , 'buying_orders.accessories as Accessories',
            'buying_orders.accys_status as Status(O/A)', 'buying_orders.care_label_composition as CareLabelComposition', 'buying_orders.ca_rn as CA/RN' )->get();
        $data['data_of_14_days_ago'] = date("Y-m-d", strtotime("today"));
        return $data;
    }

    public function getOrdersSummery()
    {
        $date_of_30_days_after = date("Y-m-d", strtotime("+1 month"));
        $date_of_14_days_ago = date("Y-m-d", strtotime("-2 week"));
        $today = date("Y-m-d");
        $data['orders_shipping_soon'] = DB::table('buying_orders')->where('handover_date', '<', $date_of_30_days_after)->where('handover_date', '>', $today)->get();
        $data['recent_orders'] = DB::table('buying_orders')->where('created_at', '>', $date_of_14_days_ago)->where('created_at', '<', $today)->get();
        $data['inactive_orders'] = DB::table('buying_orders')->where('updated_at', '<', $date_of_14_days_ago)->get();
        $data['recent_shipments'] = DB::table('buying_orders')->where('handedover_date', '>', $date_of_14_days_ago)->where('handedover_date', '<', $today)->get();
        $data['suppliers'] = DB::table('buying_orders')->join('suppliers', 'suppliers.id', '=', 'buying_orders.supplier_id')->groupBy('supplier_id')->select('suppliers.supplier_name','suppliers.id','buying_orders.supplier_id', DB::raw('count(*) as total_orders'))->get();
        return $data;
    }

    public function getSummery($id)
    {
        $data['orders'] = DB::table('buying_orders')->where('customer', $id)->get();
        $data['documents'] = DB::table('documents')->leftJoin('buying_orders', 'documents.reference_id', '=', 'buying_orders.id')->where('buying_orders.customer', $id)->select('documents.file_type','documents.filename')->get();
        return $data;

    }

    public function getOrderDetails($id)
    {
        $data['order'] = BuyingOrder::where('id', $id)->get();
        $data['suppliers'] = Supplier::where('merchandiser_id', Auth::user()->id)->get();
        $data['documents'] = Document::where('reference_id', $id)->get();
        $data['total_documents'] = Document::where('reference_id', $id)->count();
        $data['today'] = date("Y-m-d");
        $data['buyers'] = Buyer::get();
        $data['user_id'] = $data['order'][0]->merchandiser_id;
        $data['reference'] = $id;
        $data['yarn_types'] = YarnType::get();
        return view('buying.order_details', $data);

    }

    public function updateOrder(Request $request)
    {
        $order = BuyingOrder::find($request->id);
        $total = 4;
        $count = 0;
        if(!$request->knitting)
            $order->knitting = '';
        else
        {
            $count++;
        }
        if(!$request->linking)
            $order->linking = '';
        else
        {
            $count++;
        }
        if(!$request->finishing)
            $order->finishing = '';
        else
        {
            $count++;
        }
        if(!$request->packing)
            $order->packing = '';
        else
        {
            $count++;
        }
        $order->progress = ($count/$total)*100;
        $order->update($request->all());

        $calendar = new Calendar();
        $calendar->user_id = Auth::user()->id;
        $calendar->reference = $request->id;
        $calendar->reference_table = "buying_orders";
        $calendar->ip_address = $_SERVER['REMOTE_ADDR'];
        $calendar->title = "Updated order information.";
        $calendar->activity_type = "order";
        $calendar->start = date("Y-m-d h:i:s");
        $calendar->color = "#000000";
        $calendar->save();
    }

    public function uploadFiles(Request $request)
    {
        $document = new Document();
        if($request->file != ""){
            $file_extension = $request->file('file')->guessExtension();
            $img_name = time().".".$file_extension;
            $request->file('file')->move('public/uploaded', $img_name);
        }else{
            $img_name = "no_image.png";
        }

        $document->filename = $img_name;
        $document->file_type = $request->doc_type;
        $document->description = $request->description;
        $document->reference_id = $request->reference_id;
        $document->save();

        $calendar = new Calendar();
        $calendar->user_id = Auth::user()->id;
        $calendar->reference = $request->reference_id;
        $calendar->reference_table = "documents";
        $calendar->ip_address = $_SERVER['REMOTE_ADDR'];
        $calendar->title = "Uploaded files.";
        $calendar->start = date("Y-m-d h:i:s");
        $calendar->color = "#000000";
        $calendar->save();
    }

    public function savePriceChart(Request $request)
    {
        $order = Pricechart::where('order_id', $request->orderid)->count();
        if($order == 0)
        {
            $pricechart = new Pricechart();
            $pricechart->order_id = $request->orderid;
            $pricechart->price_details = json_encode($request->all());
            $pricechart->save();
        }
        else
        {
            DB::table('pricecharts')->where('order_id', $request->orderid)->update(
                [
                    'price_details' => json_encode($request->all())
                ]
            );
        }

    }

    public function confirmPrice($order_id, $supplier_id, $price)
    {
        DB::table('pricecharts')->where('order_id', $order_id)->update(
            [
                'confirmed_supplier' => $supplier_id,
                'confirmed_price' => $price
            ]
        );
        DB::table('buying_orders')->where('id', $order_id)->update(
            [
                'supplier_id' => $supplier_id,
                'confirmed_price' => $price
            ]
        );
    }
    public function loadPriceChart($id)
    {
        $data['order'] = DB::table('buying_orders')->where('id', $id)->get();
        $data['pricechart_count'] = DB::table('pricecharts')->where('order_id', $id)->count();
        $data['price_chart'] = DB::table('pricecharts')->where('order_id', $id)->get();
        $data['suppliers'] = DB::table('suppliers')->get();
        return view('buying.price_chart', $data);
    }
    public function storeOrders(Request $request)
    {
        $order_id = time();
        $order = new BuyingOrder();
        $order->id = $order_id;
        $order->style = $request->style;
        $order->ref = $request->ref;
        $order->Gauge = $request->gauge;
        $order->yarn_ref_details = $request->yarn_ref_details;
        $order->qty = $request->qty;
        $order->sizing = $request->sizing;
        $order->main_label = $request->main_label;
        $order->hang_tag = $request->hang_tag;
        $order->contract_weight = $request->contract_weight;
        $order->merchandiser_id = Auth::user()->id;
        $order->save();

        $calendar = new Calendar();
        $calendar->user_id = Auth::user()->id;
        $calendar->reference = $order_id;
        $calendar->reference_table = "buying_orders";
        $calendar->ip_address = $_SERVER['REMOTE_ADDR'];
        $calendar->title = "Created orders.";
        $calendar->start = date("Y-m-d h:i:s");
        $calendar->color = "#000000";
        $calendar->save();
    }
}
